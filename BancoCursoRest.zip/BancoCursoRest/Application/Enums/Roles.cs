﻿namespace Application.Enums
{
    public enum Roles
    {
        Admin,
        Basic
    }
}
